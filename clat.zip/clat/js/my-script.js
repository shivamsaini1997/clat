$('.testimonials-slider').slick({
  dots: false,

  infinite: true,
  autoplay: true,
  speed: 300,
  slidesToShow: 2,
  slidesToScroll: 1,
  autoplaySpeed: 1000,

  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 767,
      settings: {
        arrows: false,

        slidesToShow: 1,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        arrows: false,

        slidesToScroll: 1
      }
    }
  ]
});

const phoneValue1 = document.getElementById('validationCustom05');
let verify = $('.verify');
phoneValue1.onkeyup = () => {
  if (phoneValue1.value.length == 10) {
    verify.removeClass('d-none')
  } else {
    verify.addClass('d-none')
  }
}

const phoneValue2 = document.getElementById('validationCustom07');
phoneValue2.onkeyup = () => {
  if (phoneValue2.value.length == 10) {
    verify.removeClass('d-none')
  } else {
    verify.addClass('d-none')
  }
}
$('#exampleModal').on('hidden.bs.modal', function () {
  $(this).find('form').trigger('reset');
  verify.addClass('d-none')
})